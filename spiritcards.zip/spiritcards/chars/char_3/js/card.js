// CHAR_3 - TERRA, SPIRIT OF THE EARTH
const CHAR_3 = {
  id: "char_3",
  name: "Terra",
  title: "Espírito da Terra",
  element: "earth",
  rarity: "rare",
  hp: 300,
  atk: 55,
  def: 110,
  spd: 30,
  description: "A mais antiga de todas. Sua armadura é feita de montanhas.",
  lore: "Terra nunca ataca primeiro. Mas quando ataca, continentes se partem.",
  emoji: "🌍",
  color: "#8B6914",
  glowColor: "#C8A84B",
  bgGradient: "linear-gradient(135deg, #0d0800, #2a1a00, #4a3000)",
  abilities: [
    { id: "quake", name: "Terremoto", type: "attack", power: 80, cost: 2, description: "Abala o terreno causando dano a todos os inimigos.", element: "earth", animation: "quake", emoji: "💥", aoe: true },
    { id: "stone_wall", name: "Muralha de Pedra", type: "defense", power: 0, cost: 1, description: "Aumenta defesa em 50 por 2 turnos.", element: "earth", animation: "buff", emoji: "🧱", effect: { type: "def_boost", value: 50, turns: 2 } },
    { id: "rock_throw", name: "Arremesso de Rocha", type: "attack", power: 60, cost: 1, description: "Uma rocha maciça lançada com força brutal.", element: "earth", animation: "projectile", emoji: "🪨" },
    { id: "root_bind", name: "Raízes Presas", type: "control", power: 20, cost: 2, description: "Raízes imobilizam o oponente por 2 turnos.", element: "earth", animation: "bind", emoji: "🌿", effect: { type: "root", turns: 2 } }
  ],
  passives: [{ id: "ironclad", name: "Inexpugnável", description: "Reduz todo dano recebido em 10." }],
  evolutionFrom: null, evolutionTo: null,
  stats: { wins: 0, losses: 0, draws: 0 }
};
if (typeof module !== 'undefined') module.exports = CHAR_3;
