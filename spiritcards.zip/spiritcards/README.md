# 🌌 SPIRITCARDS — Card Game System

## Estrutura do Projeto

```
spiritcards/
├── admin.html              ← Painel do Gerente (VOCÊ)
├── player.html             ← Portal dos Jogadores
├── system/
│   ├── engine.js           ← Motor de batalha
│   └── playerSystem.js     ← Sistema de jogadores/auth
└── chars/
    ├── char_1/ (Ignis - Fogo - Lendária)
    │   ├── js/card.js
    │   └── assets/
    ├── char_2/ (Aqua - Água - Épica)
    ├── char_3/ (Terra - Terra - Rara)
    ├── char_4/ (Volt - Raio - Épica)
    ├── char_5/ (Umbra - Sombra - Lendária)
    └── char_6/ (Aether - Celestial - Mítica)
```

## Cartas incluídas

| ID | Nome | Elemento | Raridade | HP | ATK | DEF | SPD |
|----|------|----------|----------|----|-----|-----|-----|
| char_1 | Ignis | Fogo | Lendária | 180 | 95 | 40 | 70 |
| char_2 | Aqua | Água | Épica | 220 | 65 | 75 | 55 |
| char_3 | Terra | Terra | Rara | 300 | 55 | 110 | 30 |
| char_4 | Volt | Raio | Épica | 150 | 100 | 35 | 120 |
| char_5 | Umbra | Sombra | Lendária | 170 | 85 | 50 | 90 |
| char_6 | Aether | Celestial | Mítica | 200 | 80 | 80 | 80 |

## Sistema de Elementos (vantagens)
- 🔥 Fogo > Terra, Sombra
- 💧 Água > Fogo, Raio
- 🌍 Terra > Água, Raio
- ⚡ Raio > Água, Sombra
- 🌑 Sombra > Celestial, Terra
- ✨ Celestial > Sombra, Fogo

## Como criar novas cartas

1. Abra `admin.html`
2. Vá em "✨ Nova Carta"
3. Preencha os campos (ID, Nome, Elemento, etc.)
4. Configure as habilidades (máx 4)
5. Clique em "💾 Salvar Carta"
6. Copie o código JS gerado e salve em `chars/char_N/js/card.js`

## Sistema de Raridades

| Raridade | Multiplicador | Chance Booster |
|----------|---------------|----------------|
| Comum | 1.0x | 50% |
| Rara | 1.15x | 30% |
| Épica | 1.3x | 15% |
| Lendária | 1.5x | 4% |
| Mítica | 1.75x | 1% |

## Tipos de Habilidade
- **attack** — Dano ao oponente
- **defense** — Buff/escudo
- **heal** — Cura HP próprio
- **control** — Freeze, Root, Silence, Debuff
- **buff** — Aumenta atributos
- **special** — Efeitos únicos (clone, turno extra, etc.)

## Mecânicas especiais
- **pierce** — Ignora DEF do alvo
- **aoe** — Afeta todos os inimigos
- **lifesteal** — Roubo de HP
- **executer** — Dano maior contra alvos enfraquecidos
- **true_damage** — Ignora todas as resistências
- **revive** — Ressurge com % do HP
- **extra_turn** — Garante turno extra

## Sistema de Rank
Bronze → Prata → Ouro → Platina → Diamante → Mestre → Lenda

Cada vitória rankeada: +25 pontos | Derrota: -15 pontos
