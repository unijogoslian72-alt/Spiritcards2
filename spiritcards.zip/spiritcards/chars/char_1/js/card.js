// CHAR_1 - IGNIS, THE FIRE SPIRIT
const CHAR_1 = {
  id: "char_1",
  name: "Ignis",
  title: "Espírito das Chamas",
  element: "fire",
  rarity: "legendary",
  hp: 180,
  atk: 95,
  def: 40,
  spd: 70,
  description: "Um espírito ancestral nascido do núcleo vulcânico. Seu rugido acende estrelas.",
  lore: "Ignis existia antes da primeira aurora. Dizem que o Sol nada mais é que um fragmento de seu coração partido.",
  emoji: "🔥",
  color: "#FF4500",
  glowColor: "#FF6B00",
  bgGradient: "linear-gradient(135deg, #1a0000, #4a0a00, #8B1A00)",
  abilities: [
    {
      id: "fireball",
      name: "Bola de Fogo",
      type: "attack",
      power: 55,
      cost: 1,
      description: "Lança uma esfera de plasma concentrado.",
      element: "fire",
      animation: "projectile",
      emoji: "🔥"
    },
    {
      id: "inferno",
      name: "Inferno Total",
      type: "attack",
      power: 110,
      cost: 3,
      description: "O campo inteiro é consumido pelas chamas. Dano a todos os inimigos.",
      element: "fire",
      animation: "aoe",
      emoji: "💥",
      aoe: true
    },
    {
      id: "phoenix_shield",
      name: "Escudo Fênix",
      type: "defense",
      power: 0,
      cost: 2,
      description: "Ao receber dano letal, revive com 30% do HP uma vez por batalha.",
      element: "fire",
      animation: "buff",
      emoji: "🛡️",
      effect: { type: "revive", value: 0.3, once: true }
    },
    {
      id: "ember_storm",
      name: "Tempestade de Brasas",
      type: "attack",
      power: 35,
      cost: 2,
      description: "Brasas causam queimadura por 3 turnos. +15 dano/turno.",
      element: "fire",
      animation: "dot",
      emoji: "✨",
      effect: { type: "burn", damage: 15, turns: 3 }
    }
  ],
  passives: [
    { id: "heat_aura", name: "Aura de Calor", description: "Inimigos adjacentes recebem 5 dano/turno de calor." }
  ],
  evolutionFrom: null,
  evolutionTo: "char_1_evolved",
  stats: { wins: 0, losses: 0, draws: 0 }
};

if (typeof module !== 'undefined') module.exports = CHAR_1;
