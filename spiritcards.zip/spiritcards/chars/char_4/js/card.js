// CHAR_4 - VOLT, SPIRIT OF THE STORM
const CHAR_4 = {
  id: "char_4",
  name: "Volt",
  title: "Espírito da Tempestade",
  element: "lightning",
  rarity: "epic",
  hp: 150,
  atk: 100,
  def: 35,
  spd: 120,
  description: "Mais rápido que o trovão. Ataca antes que os olhos possam ver.",
  lore: "Volt não existe em um lugar. Existe em todos os lugares ao mesmo tempo — por um milissegundo.",
  emoji: "⚡",
  color: "#FFD700",
  glowColor: "#FFFF00",
  bgGradient: "linear-gradient(135deg, #0a0a00, #1a1a00, #2a2a00)",
  abilities: [
    { id: "thunderbolt", name: "Raio Certeiro", type: "attack", power: 90, cost: 2, description: "Golpe elétrico preciso. Sempre atinge primeiro.", element: "lightning", animation: "lightning", emoji: "⚡", priority: true },
    { id: "chain_lightning", name: "Relâmpago em Cadeia", type: "attack", power: 50, cost: 3, description: "Salta entre todos os inimigos causando dano.", element: "lightning", animation: "chain", emoji: "🌩️", aoe: true },
    { id: "speed_surge", name: "Surto de Velocidade", type: "buff", power: 0, cost: 1, description: "Dobra a velocidade e garante 2 ataques no próximo turno.", element: "lightning", animation: "buff", emoji: "💨", effect: { type: "double_attack", turns: 1 } },
    { id: "emp_burst", name: "Pulso EMP", type: "control", power: 20, cost: 2, description: "Desativa as habilidades especiais do oponente por 2 turnos.", element: "lightning", animation: "emp", emoji: "📡", effect: { type: "silence", turns: 2 } }
  ],
  passives: [{ id: "lightning_reflexes", name: "Reflexos Elétricos", description: "30% de chance de esquivar ataques físicos." }],
  evolutionFrom: null, evolutionTo: null,
  stats: { wins: 0, losses: 0, draws: 0 }
};
if (typeof module !== 'undefined') module.exports = CHAR_4;
