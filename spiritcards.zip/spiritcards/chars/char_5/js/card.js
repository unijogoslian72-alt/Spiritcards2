// CHAR_5 - UMBRA, SPIRIT OF SHADOWS
const CHAR_5 = {
  id: "char_5",
  name: "Umbra",
  title: "Espírito das Sombras",
  element: "shadow",
  rarity: "legendary",
  hp: 170,
  atk: 85,
  def: 50,
  spd: 90,
  description: "Existe nas brechas da realidade. Ataca de onde ninguém vê.",
  lore: "Toda sombra que já existiu foi, por um instante, Umbra.",
  emoji: "🌑",
  color: "#9B59B6",
  glowColor: "#D35400",
  bgGradient: "linear-gradient(135deg, #050010, #0d0020, #1a0040)",
  abilities: [
    { id: "shadow_strike", name: "Golpe das Sombras", type: "attack", power: 75, cost: 2, description: "Ataca ignorando toda a defesa do alvo.", element: "shadow", animation: "pierce", emoji: "🌑", pierce: true },
    { id: "nightmare", name: "Pesadelo", type: "control", power: 0, cost: 2, description: "Reduz ATK e SPD do oponente em 30% por 3 turnos.", element: "shadow", animation: "curse", emoji: "😱", effect: { type: "debuff", atk: -30, spd: -30, turns: 3, percent: true } },
    { id: "void_drain", name: "Drenagem do Vazio", type: "attack", power: 50, cost: 2, description: "Rouba 40 HP do oponente.", element: "shadow", animation: "drain", emoji: "💜", lifesteal: true, lifesteal_value: 40 },
    { id: "shadow_clone", name: "Clone de Sombra", type: "special", power: 0, cost: 3, description: "Cria uma cópia que absorve o próximo ataque.", element: "shadow", animation: "clone", emoji: "👥", effect: { type: "decoy", uses: 1 } }
  ],
  passives: [{ id: "void_walker", name: "Andarilho do Vazio", description: "Invisível no primeiro turno. Oponente não pode atacar." }],
  evolutionFrom: null, evolutionTo: null,
  stats: { wins: 0, losses: 0, draws: 0 }
};
if (typeof module !== 'undefined') module.exports = CHAR_5;
