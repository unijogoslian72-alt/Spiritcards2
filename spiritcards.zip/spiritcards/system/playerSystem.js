// SPIRITCARDS - PLAYER & GLOBAL STATE SYSTEM
// system/playerSystem.js

const PlayerSystem = {
  // Default player structure
  createPlayer(username, passwordHash) {
    return {
      id: `player_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
      username,
      passwordHash,
      email: '',
      createdAt: new Date().toISOString(),
      lastLogin: null,
      level: 1,
      xp: 0,
      xpToNext: 100,
      coins: 500, // starting coins
      gems: 10, // premium currency
      
      // Card collection: { cardId: { count, level, locked } }
      collection: {
        char_1: { count: 1, level: 1, locked: false, foil: false },
        char_3: { count: 1, level: 1, locked: false, foil: false }
      },
      
      // Deck slots (max 3 decks, each 20 cards)
      decks: [
        {
          id: "deck_1",
          name: "Deck Padrão",
          cards: ["char_1","char_1","char_3","char_3"],
          wins: 0,
          created: new Date().toISOString()
        }
      ],
      activeDeck: "deck_1",
      
      // Match history
      matchHistory: [],
      
      // Stats
      stats: {
        totalWins: 0,
        totalLosses: 0,
        totalDraws: 0,
        totalMatches: 0,
        winStreak: 0,
        bestWinStreak: 0,
        favCard: null,
        totalDamageDealt: 0
      },
      
      // Achievements earned
      achievements: [],
      
      // Ranked data
      rank: { tier: "Bronze", points: 0, season: 1 },
      
      // Inventory (boosters, consumables)
      inventory: { boosters: 1, goldBooster: 0 },
      
      // Friends
      friends: [],
      
      // Settings
      settings: { theme: "dark", sfx: true, music: true, language: "pt-BR" }
    };
  },

  // XP and leveling
  grantXP(player, amount) {
    player.xp += amount;
    while (player.xp >= player.xpToNext) {
      player.xp -= player.xpToNext;
      player.level++;
      player.xpToNext = Math.floor(player.xpToNext * 1.4);
      player.coins += 100 * player.level;
      if (player.level % 5 === 0) player.gems += 5;
    }
    return player;
  },
  
  // Record a match result
  recordMatch(player, result, opponentId, cardUsed, damage) {
    const entry = {
      id: `match_${Date.now()}`,
      date: new Date().toISOString(),
      result, // 'win' | 'loss' | 'draw'
      opponent: opponentId,
      cardUsed,
      damage,
      rankChange: 0
    };
    
    player.matchHistory.unshift(entry);
    if (player.matchHistory.length > 100) player.matchHistory = player.matchHistory.slice(0, 100);
    
    player.stats.totalMatches++;
    if (result === 'win')  { player.stats.totalWins++; player.stats.winStreak++; }
    if (result === 'loss') { player.stats.totalLosses++; player.stats.winStreak = 0; }
    if (result === 'draw') { player.stats.totalDraws++; }
    if (player.stats.winStreak > player.stats.bestWinStreak) player.stats.bestWinStreak = player.stats.winStreak;
    player.stats.totalDamageDealt += (damage || 0);
    
    // XP rewards
    const xpReward = result === 'win' ? 50 : result === 'draw' ? 20 : 10;
    this.grantXP(player, xpReward);
    
    // Coin rewards
    player.coins += result === 'win' ? 30 : result === 'draw' ? 10 : 5;
    
    return player;
  },
  
  // Ranked points
  updateRank(player, isWin) {
    const change = isWin ? 25 : -15;
    player.rank.points = Math.max(0, player.rank.points + change);
    
    const tiers = [
      { name: "Bronze", min: 0 }, { name: "Prata", min: 100 },
      { name: "Ouro", min: 250 }, { name: "Platina", min: 500 },
      { name: "Diamante", min: 800 }, { name: "Mestre", min: 1200 },
      { name: "Lenda", min: 1700 }
    ];
    for (let i = tiers.length - 1; i >= 0; i--) {
      if (player.rank.points >= tiers[i].min) { player.rank.tier = tiers[i].name; break; }
    }
    return player;
  },

  // Add a card to collection
  addCard(player, cardId, foil = false) {
    if (!player.collection[cardId]) {
      player.collection[cardId] = { count: 0, level: 1, locked: false, foil: false };
    }
    player.collection[cardId].count++;
    if (foil) player.collection[cardId].foil = true;
    return player;
  },
  
  // Open a booster pack
  openBooster(player, type = 'standard') {
    const allCards = ['char_1','char_2','char_3','char_4','char_5','char_6'];
    const rarityTable = {
      standard: [
        { rarity: 'common', cards: ['char_3'], weight: 50 },
        { rarity: 'rare', cards: ['char_2','char_4'], weight: 30 },
        { rarity: 'epic', cards: ['char_2','char_4'], weight: 15 },
        { rarity: 'legendary', cards: ['char_1','char_5'], weight: 4 },
        { rarity: 'mythic', cards: ['char_6'], weight: 1 }
      ]
    };
    
    const pack = [];
    const rolls = type === 'gold' ? 7 : 5;
    
    for (let i = 0; i < rolls; i++) {
      const roll = Math.random() * 100;
      let cumulative = 0;
      for (const tier of rarityTable.standard) {
        cumulative += tier.weight;
        if (roll <= cumulative) {
          const card = tier.cards[Math.floor(Math.random() * tier.cards.length)];
          const isFoil = Math.random() < 0.05;
          pack.push({ cardId: card, rarity: tier.rarity, foil: isFoil });
          this.addCard(player, card, isFoil);
          break;
        }
      }
    }
    
    if (type === 'standard') player.inventory.boosters--;
    else player.inventory.goldBooster--;
    
    return { player, pack };
  }
};

const GlobalState = {
  // In-memory session store (replace with DB in production)
  players: {},
  activeSessions: {},
  matchQueue: [],
  activeMatches: {},
  
  // Leaderboard snapshot
  leaderboard: [],
  
  // Register player
  register(username, password) {
    if (Object.values(this.players).find(p => p.username === username)) {
      return { success: false, error: 'Usuário já existe' };
    }
    const hash = this._simpleHash(password);
    const player = PlayerSystem.createPlayer(username, hash);
    this.players[player.id] = player;
    this._saveAll();
    return { success: true, player };
  },
  
  login(username, password) {
    const player = Object.values(this.players).find(p => p.username === username);
    if (!player) return { success: false, error: 'Usuário não encontrado' };
    if (player.passwordHash !== this._simpleHash(password)) return { success: false, error: 'Senha incorreta' };
    player.lastLogin = new Date().toISOString();
    const token = `sess_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    this.activeSessions[token] = { playerId: player.id, created: Date.now() };
    this._saveAll();
    return { success: true, player, token };
  },
  
  logout(token) {
    delete this.activeSessions[token];
    this._saveAll();
  },
  
  getPlayerByToken(token) {
    const sess = this.activeSessions[token];
    if (!sess) return null;
    return this.players[sess.playerId] || null;
  },
  
  savePlayer(player) {
    this.players[player.id] = player;
    this._saveAll();
  },
  
  updateLeaderboard() {
    this.leaderboard = Object.values(this.players)
      .sort((a,b) => b.rank.points - a.rank.points)
      .slice(0, 100)
      .map((p, i) => ({
        rank: i + 1, username: p.username, tier: p.rank.tier,
        points: p.rank.points, wins: p.stats.totalWins, level: p.level
      }));
  },
  
  _simpleHash(str) {
    // NOTE: Use bcrypt in production!
    let h = 0;
    for (let c of str) h = ((h << 5) - h) + c.charCodeAt(0);
    return (h >>> 0).toString(16);
  },
  
  _saveAll() {
    try {
      localStorage.setItem('sc_players', JSON.stringify(this.players));
      localStorage.setItem('sc_sessions', JSON.stringify(this.activeSessions));
    } catch(e) {}
  },
  
  _loadAll() {
    try {
      const p = localStorage.getItem('sc_players');
      const s = localStorage.getItem('sc_sessions');
      if (p) this.players = JSON.parse(p);
      if (s) this.activeSessions = JSON.parse(s);
    } catch(e) {}
  }
};

if (typeof module !== 'undefined') { module.exports = { PlayerSystem, GlobalState }; }
