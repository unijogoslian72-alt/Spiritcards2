// SPIRITCARDS - GAME ENGINE CORE
// system/engine.js

const GameEngine = {
  version: "1.0.0",
  
  // Element advantage matrix
  elements: {
    fire:      { strongAgainst: ["earth","shadow"], weakAgainst: ["water"], neutral: ["lightning","celestial"] },
    water:     { strongAgainst: ["fire","lightning"], weakAgainst: ["earth"], neutral: ["shadow","celestial"] },
    earth:     { strongAgainst: ["water","lightning"], weakAgainst: ["fire"], neutral: ["shadow","celestial"] },
    lightning: { strongAgainst: ["water","shadow"], weakAgainst: ["earth"], neutral: ["fire","celestial"] },
    shadow:    { strongAgainst: ["celestial","earth"], weakAgainst: ["lightning","fire"], neutral: ["water"] },
    celestial: { strongAgainst: ["shadow","fire"], weakAgainst: [], neutral: ["water","earth","lightning"] }
  },
  
  rarityMultiplier: { common: 1.0, rare: 1.15, epic: 1.3, legendary: 1.5, mythic: 1.75 },
  
  // Calculate damage
  calcDamage(attacker, defender, ability) {
    const base = ability.power;
    const atkMod = attacker.atk / 100;
    const defMod = Math.max(0.2, 1 - (defender.def / 200));
    const elemMult = this.getElementMultiplier(ability.element, defender.element);
    const rarityBonus = this.rarityMultiplier[attacker.rarity] || 1.0;
    const variance = 0.9 + Math.random() * 0.2;
    const pierceMod = ability.pierce ? 1 : defMod;
    
    let dmg = Math.floor(base * atkMod * pierceMod * elemMult * rarityBonus * variance);
    
    if (ability.true_damage) dmg = Math.floor(base * atkMod * rarityBonus * variance);
    if (ability.executer) dmg = Math.floor(dmg * (1 + (1 - defender.currentHp / defender.maxHp)));
    
    return Math.max(1, dmg);
  },
  
  getElementMultiplier(atkElem, defElem) {
    const table = this.elements[atkElem];
    if (!table) return 1.0;
    if (table.strongAgainst.includes(defElem)) return 1.5;
    if (table.weakAgainst.includes(defElem)) return 0.65;
    return 1.0;
  },
  
  applyEffect(target, effect, battle) {
    if (!effect) return;
    switch(effect.type) {
      case 'burn':    target.statusEffects.push({ type: 'burn', damage: effect.damage, turns: effect.turns }); break;
      case 'freeze':  target.statusEffects.push({ type: 'freeze', turns: effect.turns }); break;
      case 'slow':    target.spd = Math.max(1, target.spd - effect.value); break;
      case 'root':    target.statusEffects.push({ type: 'root', turns: effect.turns }); break;
      case 'silence': target.statusEffects.push({ type: 'silence', turns: effect.turns }); break;
      case 'debuff':
        if (effect.percent) {
          target.atk = Math.floor(target.atk * (1 + effect.atk/100));
          target.spd = Math.floor(target.spd * (1 + effect.spd/100));
        }
        target.statusEffects.push({ type: 'debuff', atk: effect.atk, spd: effect.spd, turns: effect.turns });
        break;
      case 'def_boost': target.statusEffects.push({ type: 'def_boost', value: effect.value, turns: effect.turns }); break;
      case 'double_attack': target.statusEffects.push({ type: 'double_attack', turns: effect.turns }); break;
      case 'decoy': target.hasDecoy = true; break;
      case 'extra_turn': battle.extraTurn = true; break;
      case 'revive': target.canRevive = { value: effect.value, used: false }; break;
      case 'mana_drain': target.mana = Math.max(0, (target.mana||0) - effect.value); break;
    }
  },
  
  processTurnEffects(fighter) {
    const dead = [];
    fighter.statusEffects = fighter.statusEffects.filter(eff => {
      if (eff.type === 'burn') { fighter.currentHp -= eff.damage; if (fighter.currentHp <= 0) dead.push(fighter); }
      eff.turns--;
      if (eff.turns <= 0) return false;
      return true;
    });
    // passive regen
    if (fighter.passives?.find(p => p.id === 'ocean_heart')) fighter.currentHp = Math.min(fighter.maxHp, fighter.currentHp + 10);
  },
  
  buildFighter(cardData) {
    return {
      ...cardData,
      maxHp: cardData.hp,
      currentHp: cardData.hp,
      mana: 100,
      maxMana: 100,
      statusEffects: [],
      hasDecoy: false,
      canRevive: null
    };
  }
};

if (typeof module !== 'undefined') module.exports = GameEngine;
