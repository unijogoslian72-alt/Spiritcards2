// CHAR_2 - AQUA, SPIRIT OF THE DEEP
const CHAR_2 = {
  id: "char_2",
  name: "Aqua",
  title: "Espírito das Profundezas",
  element: "water",
  rarity: "epic",
  hp: 220,
  atk: 65,
  def: 75,
  spd: 55,
  description: "Nascida do oceano primordial. Cura aliados e enfraquece adversários.",
  lore: "Todo ser vivo carrega uma gota de Aqua em seu sangue. Ela é a mãe silenciosa de toda vida.",
  emoji: "💧",
  color: "#00BFFF",
  glowColor: "#00DFFF",
  bgGradient: "linear-gradient(135deg, #000a1a, #001a3a, #003366)",
  abilities: [
    {
      id: "tidal_wave",
      name: "Onda Tidal",
      type: "attack",
      power: 70,
      cost: 2,
      description: "Uma onda devastadora que pode reduzir a velocidade do alvo.",
      element: "water",
      animation: "wave",
      emoji: "🌊",
      effect: { type: "slow", value: 20, chance: 60 }
    },
    {
      id: "healing_mist",
      name: "Névoa Curativa",
      type: "heal",
      power: 60,
      cost: 2,
      description: "Restaura HP de um aliado e remove um debuff.",
      element: "water",
      animation: "heal",
      emoji: "💚",
      heal: true
    },
    {
      id: "ice_prison",
      name: "Prisão de Gelo",
      type: "control",
      power: 30,
      cost: 3,
      description: "Congela o alvo por 2 turnos. Alvo não pode agir.",
      element: "water",
      animation: "freeze",
      emoji: "❄️",
      effect: { type: "freeze", turns: 2 }
    },
    {
      id: "whirlpool",
      name: "Redemoinho",
      type: "attack",
      power: 45,
      cost: 2,
      description: "Puxa e drena energia do oponente. Rouba 20 de mana.",
      element: "water",
      animation: "drain",
      emoji: "🌀",
      effect: { type: "mana_drain", value: 20 }
    }
  ],
  passives: [
    { id: "ocean_heart", name: "Coração do Oceano", description: "Regenera 10 HP por turno." }
  ],
  evolutionFrom: null,
  evolutionTo: null,
  stats: { wins: 0, losses: 0, draws: 0 }
};

if (typeof module !== 'undefined') module.exports = CHAR_2;
