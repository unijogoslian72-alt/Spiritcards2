// CHAR_6 - AETHER, CELESTIAL SPIRIT
const CHAR_6 = {
  id: "char_6",
  name: "Aether",
  title: "Espírito Celestial",
  element: "celestial",
  rarity: "mythic",
  hp: 200,
  atk: 80,
  def: 80,
  spd: 80,
  description: "Equilíbrio perfeito entre todos os elementos. O árbitro do cosmos.",
  lore: "Aether não escolhe lados. Mas quando o equilíbrio é rompido, sua ira não tem precedente.",
  emoji: "✨",
  color: "#E8D5B7",
  glowColor: "#FFFFFF",
  bgGradient: "linear-gradient(135deg, #0a0a14, #14142a, #1e1e3f)",
  abilities: [
    { id: "starburst", name: "Explosão Estelar", type: "attack", power: 85, cost: 2, description: "Energia celestial pura. Ignora resistências elementais.", element: "celestial", animation: "starburst", emoji: "💫", true_damage: true },
    { id: "cosmic_heal", name: "Cura Cósmica", type: "heal", power: 80, cost: 2, description: "Restaura HP e remove todos os debuffs do aliado.", element: "celestial", animation: "heal", emoji: "⭐", cleanse: true },
    { id: "divine_judgment", name: "Julgamento Divino", type: "attack", power: 60, cost: 3, description: "Dano proporcional ao HP perdido do oponente. Mais poderoso quando oponente está fraco.", element: "celestial", animation: "judgment", emoji: "⚖️", executer: true },
    { id: "time_warp", name: "Dobra Temporal", type: "special", power: 0, cost: 3, description: "Permite jogar novamente este turno.", element: "celestial", animation: "timewarp", emoji: "🕐", effect: { type: "extra_turn" } }
  ],
  passives: [{ id: "cosmic_balance", name: "Equilíbrio Cósmico", description: "Resistente a todos os elementos em 20%." }],
  evolutionFrom: null, evolutionTo: null,
  stats: { wins: 0, losses: 0, draws: 0 }
};
if (typeof module !== 'undefined') module.exports = CHAR_6;
